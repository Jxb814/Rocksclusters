
clients_machine_ip = []
clients_monitor_count = 0